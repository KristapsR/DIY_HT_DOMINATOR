//-----------------------------------------------------------------------------
// File: stdafx.cpp
// Desc: source file that includes just the standard includes
//  HeadTrackerGUI.pch will be the pre-compiled header
//  stdafx.obj will contain the pre-compiled type information
//-----------------------------------------------------------------------------

#include "stdafx.h"


